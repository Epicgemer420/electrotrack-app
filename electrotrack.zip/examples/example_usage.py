"""Example usage of ElectroTrack system"""

from electrotrack.main import ElectroTrack
from electrotrack.models.athlete import AthleteProfile
from electrotrack.models.workout import WorkoutMetrics, EnvironmentalData, WorkoutType
from electrotrack.models.recommendation import HydrationRecommendation


def example_1_high_intensity():
    """Example 1: High-intensity outdoor 10K run"""
    print("=" * 60)
    print("Example 1: High-Intensity 10K Run")
    print("=" * 60)
    
    # Initialize system
    system = ElectroTrack()
    
    # Register athlete
    profile = AthleteProfile(
        age=25,
        gender='M',
        weight_kg=70.0,
        height_cm=175.0,
        activity_level='competitive',
        baseline_heart_rate=60
    )
    athlete = system.register_athlete("athlete_001", profile)
    
    # Workout metrics
    metrics = WorkoutMetrics(
        duration_minutes=45.0,
        average_heart_rate_bpm=175,
        max_heart_rate_bpm=185,
        pre_workout_weight_kg=70.0,
        post_workout_weight_kg=68.8,  # 1.2 kg loss
        fluid_intake_liters=1.5,
        workout_type=WorkoutType.DISTANCE,
        distance_km=10.0,
        intensity_level='high'
    )
    
    # Environmental conditions
    environmental = EnvironmentalData(
        temperature_fahrenheit=85.0,
        humidity_percent=60.0,
        location="outdoor"
    )
    
    # Get recommendation
    recommendation = system.get_recommendation(
        "athlete_001", metrics, environmental
    )
    
    print(f"\nInput:")
    print(f"  - Workout: 10K run, 45 minutes")
    print(f"  - Temperature: 85°F")
    print(f"  - Average HR: 175 bpm")
    print(f"  - Weight loss: 1.2 kg")
    print(f"  - Fluid intake: 1.5 L")
    
    print(f"\nOutput:")
    print(str(recommendation))
    
    return recommendation


def example_2_moderate_indoor():
    """Example 2: Moderate indoor training"""
    print("\n" + "=" * 60)
    print("Example 2: Moderate Indoor Training")
    print("=" * 60)
    
    # Initialize system
    system = ElectroTrack()
    
    # Register athlete
    profile = AthleteProfile(
        age=22,
        gender='F',
        weight_kg=60.0,
        height_cm=165.0,
        activity_level='competitive',
        baseline_heart_rate=65
    )
    athlete = system.register_athlete("athlete_002", profile)
    
    # Workout metrics
    metrics = WorkoutMetrics(
        duration_minutes=45.0,
        average_heart_rate_bpm=140,
        pre_workout_weight_kg=60.0,
        post_workout_weight_kg=59.95,  # Minimal loss
        fluid_intake_liters=0.3,
        workout_type=WorkoutType.RUNNING,
        intensity_level='moderate'
    )
    
    # Environmental conditions
    environmental = EnvironmentalData(
        temperature_fahrenheit=70.0,
        humidity_percent=40.0,
        location="indoor"
    )
    
    # Get recommendation
    recommendation = system.get_recommendation(
        "athlete_002", metrics, environmental
    )
    
    print(f"\nInput:")
    print(f"  - Workout: Indoor training, 45 minutes")
    print(f"  - Temperature: 70°F")
    print(f"  - Average HR: 140 bpm")
    print(f"  - Weight loss: minimal")
    print(f"  - Humidity: 40%")
    
    print(f"\nOutput:")
    print(str(recommendation))
    
    return recommendation


def example_3_real_time_session():
    """Example 3: Real-time workout session monitoring"""
    print("\n" + "=" * 60)
    print("Example 3: Real-Time Session Monitoring")
    print("=" * 60)
    
    # Initialize system
    system = ElectroTrack()
    
    # Register athlete
    profile = AthleteProfile(
        age=28,
        gender='M',
        weight_kg=75.0,
        height_cm=180.0,
        activity_level='elite',
        baseline_heart_rate=55
    )
    athlete = system.register_athlete("athlete_003", profile)
    
    # Start session with initial metrics
    initial_metrics = WorkoutMetrics(
        duration_minutes=0.0,
        average_heart_rate_bpm=65,
        pre_workout_weight_kg=75.0,
        workout_type=WorkoutType.INTERVAL,
        intensity_level='moderate'
    )
    
    environmental = EnvironmentalData(
        temperature_fahrenheit=82.0,
        humidity_percent=55.0,
        location="outdoor_track"
    )
    
    session_id = system.start_workout_session(
        "athlete_003", initial_metrics, environmental
    )
    
    print(f"\nSession started: {session_id}")
    
    # Simulate updates during workout
    updates = [
        (15.0, 150, 75.0),  # 15 min, HR 150, weight same
        (30.0, 165, 74.5),  # 30 min, HR 165, 0.5 kg loss
        (45.0, 170, 74.0),  # 45 min, HR 170, 1.0 kg loss
    ]
    
    for duration, hr, weight in updates:
        update_metrics = WorkoutMetrics(
            duration_minutes=duration,
            average_heart_rate_bpm=hr,
            pre_workout_weight_kg=75.0,
            post_workout_weight_kg=weight,
            workout_type=WorkoutType.INTERVAL,
            intensity_level='high' if hr > 165 else 'moderate'
        )
        
        recommendation = system.update_workout_session(session_id, update_metrics)
        
        if recommendation:
            print(f"\n[{duration} min] Update:")
            print(f"  HR: {hr} bpm, Weight loss: {75.0 - weight:.2f} kg")
            print(f"  Recommendation: {recommendation.volume_liters:.2f} L "
                  f"{recommendation.drink_type.value}")
    
    # End session
    final_metrics = WorkoutMetrics(
        duration_minutes=45.0,
        average_heart_rate_bpm=170,
        pre_workout_weight_kg=75.0,
        post_workout_weight_kg=73.8,  # 1.2 kg loss
        fluid_intake_liters=0.5,
        workout_type=WorkoutType.INTERVAL,
        intensity_level='high'
    )
    
    workout, final_rec = system.end_workout_session(session_id, final_metrics)
    
    print(f"\n--- Final Recommendation ---")
    print(str(final_rec))
    
    return final_rec


if __name__ == "__main__":
    # Run examples
    example_1_high_intensity()
    example_2_moderate_indoor()
    example_3_real_time_session()
    
    print("\n" + "=" * 60)
    print("All examples completed!")

