"""
ElectroTrack - AI-Powered Hydration Monitoring System for Track and Field Athletes
"""

__version__ = "1.0.0"

