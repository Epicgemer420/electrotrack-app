"""Real-time processing engine"""

from .session_processor import SessionProcessor

__all__ = ['SessionProcessor']

