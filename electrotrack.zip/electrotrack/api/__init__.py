"""API integrations for external data"""

from .weather_api import WeatherAPI

__all__ = ['WeatherAPI']

