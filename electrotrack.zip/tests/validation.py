"""Validation framework for ElectroTrack system"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from electrotrack.main import ElectroTrack
from electrotrack.models.athlete import AthleteProfile
from electrotrack.models.workout import Workout, WorkoutMetrics, EnvironmentalData, WorkoutType
from electrotrack.models.recommendation import HydrationRecommendation, DrinkType
from electrotrack.ml.hydration_predictor import HydrationPredictor


class ValidationFramework:
    """Framework for validating ElectroTrack system with controlled trials"""
    
    def __init__(self):
        self.system = ElectroTrack()
        self.test_results = []
    
    def run_controlled_trial(
        self,
        athlete_id: str,
        profile: AthleteProfile,
        workout_scenarios: list
    ) -> dict:
        """
        Run controlled trial with predefined scenarios
        
        Args:
            athlete_id: Athlete identifier
            profile: Athlete profile
            workout_scenarios: List of (metrics, environmental, expected_range) tuples
            
        Returns:
            Validation results
        """
        # Register athlete
        athlete = self.system.register_athlete(athlete_id, profile)
        
        results = {
            'athlete_id': athlete_id,
            'scenarios': [],
            'accuracy': 0.0
        }
        
        for i, (metrics, environmental, expected_range) in enumerate(workout_scenarios):
            recommendation = self.system.get_recommendation(
                athlete_id, metrics, environmental
            )
            
            # Validate recommendation
            is_valid = (
                expected_range['min_volume'] <= recommendation.volume_liters <= expected_range['max_volume']
            )
            
            scenario_result = {
                'scenario': i + 1,
                'recommendation': recommendation.to_dict(),
                'expected_range': expected_range,
                'is_valid': is_valid
            }
            
            results['scenarios'].append(scenario_result)
            self.test_results.append(scenario_result)
        
        # Calculate accuracy
        valid_count = sum(1 for s in results['scenarios'] if s['is_valid'])
        results['accuracy'] = valid_count / len(results['scenarios']) if results['scenarios'] else 0.0
        
        return results
    
    def test_example_scenarios(self):
        """Test the two provided examples"""
        print("=" * 60)
        print("Validation: Testing Example Scenarios")
        print("=" * 60)
        
        # Example 1: High-intensity 10K
        print("\n--- Scenario 1: High-Intensity 10K Run ---")
        
        profile1 = AthleteProfile(
            age=25,
            gender='M',
            weight_kg=70.0,
            height_cm=175.0,
            activity_level='competitive',
            baseline_heart_rate=60
        )
        
        # Register athlete
        self.system.register_athlete("test_001", profile1)
        
        metrics1 = WorkoutMetrics(
            duration_minutes=45.0,
            average_heart_rate_bpm=175,
            max_heart_rate_bpm=185,
            pre_workout_weight_kg=70.0,
            post_workout_weight_kg=68.8,  # 1.2 kg loss
            fluid_intake_liters=1.5,
            workout_type=WorkoutType.DISTANCE,
            distance_km=10.0,
            intensity_level='high'
        )
        
        environmental1 = EnvironmentalData(
            temperature_fahrenheit=85.0,
            humidity_percent=60.0,
            location="outdoor"
        )
        
        # Expected: 0.6 L electrolyte drink (medium sodium)
        expected1 = {
            'min_volume': 0.4,
            'max_volume': 0.8,
            'drink_type': DrinkType.ELECTROLYTE_MEDIUM
        }
        
        rec1 = self.system.get_recommendation("test_001", metrics1, environmental1)
        
        print(f"Recommended: {rec1.volume_liters:.2f} L, Type: {rec1.drink_type.value}")
        print(f"Expected: {expected1['min_volume']:.2f}-{expected1['max_volume']:.2f} L, Type: {expected1['drink_type'].value}")
        print(f"Valid: {expected1['min_volume'] <= rec1.volume_liters <= expected1['max_volume']}")
        print(f"Drink Type Match: {rec1.drink_type == expected1['drink_type']}")
        
        # Example 2: Moderate indoor
        print("\n--- Scenario 2: Moderate Indoor Training ---")
        
        profile2 = AthleteProfile(
            age=22,
            gender='F',
            weight_kg=60.0,
            height_cm=165.0,
            activity_level='competitive',
            baseline_heart_rate=65
        )
        
        metrics2 = WorkoutMetrics(
            duration_minutes=45.0,
            average_heart_rate_bpm=140,
            pre_workout_weight_kg=60.0,
            post_workout_weight_kg=59.95,  # Minimal loss
            fluid_intake_liters=0.3,
            workout_type=WorkoutType.RUNNING,
            intensity_level='moderate'
        )
        
        environmental2 = EnvironmentalData(
            temperature_fahrenheit=70.0,
            humidity_percent=40.0,
            location="indoor"
        )
        
        # Expected: 0.3 L water
        expected2 = {
            'min_volume': 0.2,
            'max_volume': 0.4,
            'drink_type': DrinkType.WATER
        }
        
        self.system.register_athlete("test_002", profile2)
        rec2 = self.system.get_recommendation("test_002", metrics2, environmental2)
        
        print(f"Recommended: {rec2.volume_liters:.2f} L, Type: {rec2.drink_type.value}")
        print(f"Expected: {expected2['min_volume']:.2f}-{expected2['max_volume']:.2f} L, Type: {expected2['drink_type'].value}")
        print(f"Valid: {expected2['min_volume'] <= rec2.volume_liters <= expected2['max_volume']}")
        print(f"Drink Type Match: {rec2.drink_type == expected2['drink_type']}")
        
        print("\n" + "=" * 60)
        print("Validation complete!")
    
    def test_model_training(self):
        """Test model training functionality"""
        print("\n" + "=" * 60)
        print("Validation: Testing Model Training")
        print("=" * 60)
        
        # Generate synthetic workout data
        profiles = [
            AthleteProfile(age=25, gender='M', weight_kg=70.0, height_cm=175.0, 
                          activity_level='competitive', baseline_heart_rate=60),
            AthleteProfile(age=22, gender='F', weight_kg=60.0, height_cm=165.0,
                          activity_level='competitive', baseline_heart_rate=65),
        ]
        
        athletes = [
            self.system.register_athlete(f"train_{i}", profile)
            for i, profile in enumerate(profiles)
        ]
        
        # Create multiple workouts
        import random
        for i in range(15):
            athlete_id = f"train_{i % 2}"
            metrics = WorkoutMetrics(
                duration_minutes=random.uniform(30, 60),
                average_heart_rate_bpm=random.randint(130, 180),
                pre_workout_weight_kg=random.uniform(60, 75),
                post_workout_weight_kg=random.uniform(58, 73),
                fluid_intake_liters=random.uniform(0, 1.5),
                workout_type=random.choice(list(WorkoutType)),
                intensity_level=random.choice(['low', 'moderate', 'high', 'extreme'])
            )
            
            environmental = EnvironmentalData(
                temperature_fahrenheit=random.uniform(65, 90),
                humidity_percent=random.uniform(30, 70)
            )
            
            self.system.get_recommendation(athlete_id, metrics, environmental)
        
        # Train model
        try:
            metrics = self.system.train_model(min_workouts=10)
            print(f"\nTraining successful!")
            print(f"Volume MAE: {metrics['volume_mae']:.3f}")
            print(f"Drink Type MAE: {metrics['drink_type_mae']:.3f}")
            print(f"Samples trained: {metrics['samples_trained']}")
        except Exception as e:
            print(f"\nTraining error: {e}")
    
    def test_privacy_features(self):
        """Test privacy and security features"""
        print("\n" + "=" * 60)
        print("Validation: Testing Privacy Features")
        print("=" * 60)
        
        from electrotrack.security.encryption import encrypt_data, decrypt_data
        from electrotrack.security.anonymizer import anonymize_athlete_data
        
        # Test encryption
        test_data = {'athlete_id': 'test_123', 'name': 'John Doe'}
        encrypted = encrypt_data(test_data, fields=['athlete_id'])
        decrypted = decrypt_data(encrypted, fields=['athlete_id'])
        
        print(f"\nEncryption Test:")
        print(f"Original: {test_data['athlete_id']}")
        print(f"Encrypted: {encrypted['athlete_id'][:20]}...")
        print(f"Decrypted: {decrypted['athlete_id']}")
        print(f"Match: {test_data['athlete_id'] == decrypted['athlete_id']}")
        
        # Test anonymization
        profile = AthleteProfile(
            age=25, gender='M', weight_kg=70.0, height_cm=175.0,
            activity_level='competitive'
        )
        athlete = self.system.register_athlete("anon_test", profile)
        anonymized = anonymize_athlete_data(athlete)
        
        print(f"\nAnonymization Test:")
        print(f"Anonymous ID: {anonymized['anonymous_id']}")
        print(f"Age Range: {anonymized['age_range']}")
        print(f"Weight Range: {anonymized['weight_range']}")
        print(f"Original ID hidden: {'anon_test' not in str(anonymized)}")


def main():
    """Run validation tests"""
    framework = ValidationFramework()
    
    # Run validations
    framework.test_example_scenarios()
    framework.test_model_training()
    framework.test_privacy_features()
    
    print("\n" + "=" * 60)
    print("All validation tests completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()

